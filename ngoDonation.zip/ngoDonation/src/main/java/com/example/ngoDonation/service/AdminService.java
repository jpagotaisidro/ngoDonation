package com.example.ngoDonation.service;

import org.springframework.stereotype.Service;
import com.example.ngoDonation.entity.User;

@Service
public class AdminService {

	
	
}
