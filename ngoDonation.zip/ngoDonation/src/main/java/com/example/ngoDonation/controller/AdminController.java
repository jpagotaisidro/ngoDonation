package com.example.ngoDonation.controller;

public class AdminController {

}
