package com.example.ngoDonation.repo;

public interface DonationRepository {

}
