package com.example.ngoDonation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NgoDonationApplication {

	public static void main(String[] args) {
		SpringApplication.run(NgoDonationApplication.class, args);
	}

}
