package com.example.ngoDonation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NgoDonationApplicationTests {

	@Test
	void contextLoads() {
	}

}
